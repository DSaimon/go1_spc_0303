package main // он также находится в main, НО ФУНКЦИЯ MAIN() одна на весь пакет!

//Реализуем 4 функции в моделе calculator

func add(a, b int) int {
	return a + b
}

func Sub(a, b int) int {
	return a - b
}

func Mult(a, b int) int {
	return a * b
}

func Div(a, b int) int {
	return a / b
}
