package main //package name

import "fmt"

func main() {
	fmt.Println("Hello world!")
}
